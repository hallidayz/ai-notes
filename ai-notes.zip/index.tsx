import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { pipeline, AutoTokenizer, AutoModelForSeq2SeqLM } from '@xenova/transformers';

// --- ON-DEVICE AI SERVICE ---
class OnDeviceAIService {
    private static instance: OnDeviceAIService | null = null;
    private transcriptionPipe: any = null;
    private analysisPipe: any = null;
    private tokenizer: any = null;
    private model: any = null;

    private constructor() {}

    public static getInstance(): OnDeviceAIService {
        if (!this.instance) {
            this.instance = new OnDeviceAIService();
        }
        return this.instance;
    }

    private async getTranscriptionPipeline(progress_callback?: (progress: any) => void) {
        if (!this.transcriptionPipe) {
            this.transcriptionPipe = await pipeline('automatic-speech-recognition', 'Xenova/whisper-tiny.en', {
                progress_callback,
            });
        }
        return this.transcriptionPipe;
    }

    private async getAnalysisPipeline(progress_callback?: (progress: any) => void) {
        if (!this.tokenizer || !this.model) {
            this.tokenizer = await AutoTokenizer.from_pretrained('Xenova/LaMini-Flan-T5-783M', { progress_callback });
            this.model = await AutoModelForSeq2SeqLM.from_pretrained('Xenova/LaMini-Flan-T5-783M', { progress_callback });
        }
    }

    public async analyze(
        audio: AudioBuffer,
        progressCallback: (status: string, progress?: number) => void
    ): Promise<{ transcript: any[], summary: string, action_items: string[], outline: string }> {
        // 1. Transcription
        progressCallback('Initializing transcription model...');
        const transcriber = await this.getTranscriptionPipeline((p: any) => {
            if (p.status === 'progress') {
                progressCallback('Downloading transcription model...', p.progress);
            }
        });

        progressCallback('Transcribing audio...');
        const transcription = await transcriber(audio.getChannelData(0), {
            chunk_length_s: 30,
            stride_length_s: 5,
            return_timestamps: true,
        });

        const transcriptChunks = (transcription.chunks || []).map((chunk: any) => ({
             speaker: 'Speaker 1', 
             text: chunk.text
        }));

        const fullTranscript = transcriptChunks.map(c => c.text).join(' ');
        
        if (!fullTranscript.trim()) {
            return { transcript: [], summary: '', action_items: [], outline: '' };
        }

        // 2. Analysis (Summary, Todos, Outline)
        progressCallback('Initializing analysis model...');
        await this.getAnalysisPipeline((p: any) => {
            if (p.status === 'progress') {
                progressCallback('Downloading analysis model...', p.progress);
            }
        });
        
        progressCallback('Analyzing transcript...');
        const prompt = `Given the following transcript, perform these tasks:
1. Write a concise summary.
2. Extract a list of actionable to-do items.
3. Create a structured outline of the key topics.

Format the output as a JSON object with the keys "summary", "action_items", and "outline". Do not include any other text or explanations.

Transcript:
${fullTranscript}`;

        const inputs = this.tokenizer(prompt, {
            return_tensors: 'pt'
        });
        const output = await this.model.generate({ ...inputs, max_new_tokens: 512 });
        const resultText = this.tokenizer.decode(output[0], { skip_special_tokens: true });

        try {
            // Attempt to find a valid JSON object within the result text
            const jsonMatch = resultText.match(/\{[\s\S]*\}/);
            if (!jsonMatch) {
                throw new Error("No JSON object found in the model's response.");
            }
            const parsedResult = JSON.parse(jsonMatch[0]);
            return {
                transcript: transcriptChunks,
                summary: parsedResult.summary || 'No summary generated.',
                action_items: parsedResult.action_items || [],
                outline: parsedResult.outline || 'No outline generated.'
            };
        } catch (error) {
            console.error("Failed to parse AI analysis response:", resultText, error);
            throw new Error("Failed to parse on-device AI analysis.");
        }
    }
}


// --- FIX for SpeechRecognition API types ---
interface SpeechRecognitionAlternative {
    transcript: string;
}

interface SpeechRecognitionResult {
    isFinal: boolean;
    [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionResultList {
    [index: number]: SpeechRecognitionResult;
    length: number;
}

interface SpeechRecognitionEvent extends Event {
    resultIndex: number;
    results: SpeechRecognitionResultList;
}

interface SpeechRecognition extends EventTarget {
    continuous: boolean;
    interimResults: boolean;
    onresult: (event: SpeechRecognitionEvent) => void;
    start: () => void;
    stop: () => void;
}

declare global {
    interface Window {
        SpeechRecognition: new () => SpeechRecognition;
        webkitSpeechRecognition: new () => SpeechRecognition;
        AudioContext: typeof AudioContext;
        webkitAudioContext: typeof AudioContext;
    }
    interface HTMLAudioElement {
      setSinkId(sinkId: string): Promise<void>;
    }
}

// --- TYPE DEFINITIONS ---
interface TranscriptChunk {
    speaker: string;
    text: string;
}

interface TodoItem {
    text: string;
    completed: boolean;
    promotedToTaskId?: number;
}

interface Session {
    id?: number;
    sessionTitle: string;
    participants?: string;
    date: string;
    notes: string;
    duration: number;
    transcript: TranscriptChunk[];
    timestamp: number;
    summary?: string;
    todoItems?: TodoItem[];
    outline?: string;
    analysisStatus?: 'pending' | 'complete' | 'failed' | 'none';
    audioBlob?: Blob;
}

interface Task {
    id?: number;
    title: string;
    dueDate: string | null;
    priority: 'low' | 'medium' | 'high';
    status: 'todo' | 'inprogress' | 'done';
    sessionId?: number;
    sessionName?: string;
    timestamp: number;
}

// --- CRYPTO SERVICE ---
class CryptoService {
    private static readonly SALT = 'a-very-secure-static-salt-for-whisper-notes'; // In a real app, this might be user-specific
    private static readonly ITERATIONS = 100000;

    private static async deriveKey(pin: string): Promise<CryptoKey> {
        const enc = new TextEncoder();
        const keyMaterial = await window.crypto.subtle.importKey(
            'raw',
            enc.encode(pin),
            { name: 'PBKDF2' },
            false,
            ['deriveKey']
        );
        return window.crypto.subtle.deriveKey(
            {
                name: 'PBKDF2',
                salt: enc.encode(this.SALT),
                iterations: this.ITERATIONS,
                hash: 'SHA-256',
            },
            keyMaterial,
            { name: 'AES-GCM', length: 256 },
            true,
            ['encrypt', 'decrypt']
        );
    }

    public static async encrypt(data: string, pin: string): Promise<string> {
        const key = await this.deriveKey(pin);
        const iv = window.crypto.getRandomValues(new Uint8Array(12));
        const enc = new TextEncoder();
        const encoded = enc.encode(data);
        const encryptedContent = await window.crypto.subtle.encrypt(
            {
                name: 'AES-GCM',
                iv: iv,
            },
            key,
            encoded
        );

        const encryptedBytes = new Uint8Array(iv.length + encryptedContent.byteLength);
        encryptedBytes.set(iv, 0);
        encryptedBytes.set(new Uint8Array(encryptedContent), iv.length);

        return btoa(String.fromCharCode.apply(null, Array.from(encryptedBytes)));
    }

    public static async decrypt(encryptedData: string, pin: string): Promise<string> {
        try {
            const key = await this.deriveKey(pin);
            const encryptedBytes = new Uint8Array(Array.from(atob(encryptedData), c => c.charCodeAt(0)));
            const iv = encryptedBytes.slice(0, 12);
            const encryptedContent = encryptedBytes.slice(12);

            const decryptedContent = await window.crypto.subtle.decrypt(
                {
                    name: 'AES-GCM',
                    iv: iv,
                },
                key,
                encryptedContent
            );

            const dec = new TextDecoder();
            return dec.decode(decryptedContent);
        } catch (e) {
            console.error("Decryption failed:", e);
            throw new Error("Invalid PIN or corrupted data.");
        }
    }
}

// --- DATABASE SERVICE ---
class TherapyDB {
    private db: IDBDatabase | null = null;
    private readonly DB_NAME = 'TherapyNotesDB';
    private readonly SESSIONS_STORE = 'sessions';
    private readonly TASKS_STORE = 'tasks';
    private readonly CONFIG_STORE = 'config';

    constructor() {
        this.init();
    }

    private init(): Promise<void> {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.DB_NAME, 3);

            request.onupgradeneeded = (event) => {
                const db = (event.target as IDBOpenDBRequest).result;
                if (!db.objectStoreNames.contains(this.SESSIONS_STORE)) {
                    db.createObjectStore(this.SESSIONS_STORE, { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains(this.TASKS_STORE)) {
                    const taskStore = db.createObjectStore(this.TASKS_STORE, { keyPath: 'id', autoIncrement: true });
                    taskStore.createIndex('timestamp', 'timestamp', { unique: false });
                }
                if (!db.objectStoreNames.contains(this.CONFIG_STORE)) {
                    db.createObjectStore(this.CONFIG_STORE, { keyPath: 'key' });
                }
            };

            request.onsuccess = (event) => {
                this.db = (event.target as IDBOpenDBRequest).result;
                resolve();
            };

            request.onerror = (event) => {
                console.error("Database error: ", (event.target as IDBOpenDBRequest).error);
                reject((event.target as IDBOpenDBRequest).error);
            };
        });
    }

    private async getDb(): Promise<IDBDatabase> {
        if (!this.db) {
            await this.init();
        }
        return this.db!;
    }

    public async saveConfig(key: string, value: any): Promise<void> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.CONFIG_STORE, 'readwrite');
            const store = transaction.objectStore(this.CONFIG_STORE);
            const request = store.put({ key, value });
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    public async getConfig(key: string): Promise<any> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.CONFIG_STORE, 'readonly');
            const store = transaction.objectStore(this.CONFIG_STORE);
            const request = store.get(key);
            request.onsuccess = () => resolve(request.result?.value);
            request.onerror = () => reject(request.error);
        });
    }

    public async addSession(session: Session): Promise<number> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.SESSIONS_STORE, 'readwrite');
            const store = transaction.objectStore(this.SESSIONS_STORE);
            const request = store.add(session);
            request.onsuccess = () => resolve(request.result as number);
            request.onerror = () => reject(request.error);
        });
    }

    public async getAllSessions(): Promise<Session[]> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.SESSIONS_STORE, 'readonly');
            const store = transaction.objectStore(this.SESSIONS_STORE);
            const request = store.getAll();
            request.onsuccess = () => {
                const sortedSessions = request.result.sort((a, b) => b.timestamp - a.timestamp);
                resolve(sortedSessions);
            };
            request.onerror = () => reject(request.error);
        });
    }

    public async getSession(id: number): Promise<Session | undefined> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.SESSIONS_STORE, 'readonly');
            const store = transaction.objectStore(this.SESSIONS_STORE);
            const request = store.get(id);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    
    public async updateSession(session: Session): Promise<void> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.SESSIONS_STORE, 'readwrite');
            const store = transaction.objectStore(this.SESSIONS_STORE);
            const request = store.put(session);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    public async deleteSession(id: number): Promise<void> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.SESSIONS_STORE, 'readwrite');
            const store = transaction.objectStore(this.SESSIONS_STORE);
            const request = store.delete(id);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // Task Methods
    public async addTask(task: Task): Promise<number> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.TASKS_STORE, 'readwrite');
            const store = transaction.objectStore(this.TASKS_STORE);
            const request = store.add(task);
            request.onsuccess = () => resolve(request.result as number);
            request.onerror = () => reject(request.error);
        });
    }

    public async getAllTasks(): Promise<Task[]> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.TASKS_STORE, 'readonly');
            const store = transaction.objectStore(this.TASKS_STORE);
            const index = store.index('timestamp');
            const request = index.getAll();
            request.onsuccess = () => {
                const sortedTasks = request.result.sort((a, b) => b.timestamp - a.timestamp);
                resolve(sortedTasks);
            };
            request.onerror = () => reject(request.error);
        });
    }

    public async updateTask(task: Task): Promise<void> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.TASKS_STORE, 'readwrite');
            const store = transaction.objectStore(this.TASKS_STORE);
            const request = store.put(task);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    public async deleteTask(id: number): Promise<void> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.TASKS_STORE, 'readwrite');
            const store = transaction.objectStore(this.TASKS_STORE);
            const request = store.delete(id);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // Audio Blob Methods
    public async saveAudioBlob(sessionId: number, blob: Blob): Promise<void> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.SESSIONS_STORE, 'readwrite');
            const store = transaction.objectStore(this.SESSIONS_STORE);
            const getRequest = store.get(sessionId);
            getRequest.onsuccess = () => {
                const session = getRequest.result;
                if (session) {
                    session.audioBlob = blob;
                    const putRequest = store.put(session);
                    putRequest.onsuccess = () => resolve();
                    putRequest.onerror = () => reject(putRequest.error);
                } else {
                    reject(new Error("Session not found"));
                }
            };
            getRequest.onerror = () => reject(getRequest.error);
        });
    }

    public async getAudioBlob(sessionId: number): Promise<Blob | undefined> {
        const db = await this.getDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(this.SESSIONS_STORE, 'readonly');
            const store = transaction.objectStore(this.SESSIONS_STORE);
            const request = store.get(sessionId);
            request.onsuccess = () => resolve(request.result?.audioBlob);
            request.onerror = () => reject(request.error);
        });
    }
}

const db = new TherapyDB();
const onDeviceAIService = OnDeviceAIService.getInstance();

// --- COMPONENTS ---
const App: React.FC = () => {
    const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
    const [pin, setPin] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);

    useEffect(() => {
        const checkPin = async () => {
            const storedPinHash = await db.getConfig('pinHash');
            if (!storedPinHash) {
                // First time setup
                setIsAuthenticated(true);
            }
            setIsLoading(false);
        };
        checkPin();
    }, []);

    const handlePinSet = (newPin: string) => {
        setPin(newPin);
        setIsAuthenticated(true);
    };

    const handleLogin = (enteredPin: string) => {
        setPin(enteredPin);
        setIsAuthenticated(true);
    };

    if (isLoading) {
        return <div className="loading">Loading...</div>;
    }

    return isAuthenticated ? <MainApp pin={pin!} /> : <AuthScreen onPinSet={handlePinSet} onLogin={handleLogin} />;
};

const AuthScreen: React.FC<{ onPinSet: (pin: string) => void, onLogin: (pin: string) => void }> = ({ onPinSet, onLogin }) => {
    const [isSetup, setIsSetup] = useState(false);
    const [pin, setPin] = useState('');
    const [confirmPin, setConfirmPin] = useState('');
    const [isConfirming, setIsConfirming] = useState(false);
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isVerifying, setIsVerifying] = useState(false);

    useEffect(() => {
        const checkSetup = async () => {
            const storedPinHash = await db.getConfig('pinHash');
            setIsSetup(!!storedPinHash);
            setIsLoading(false);
        };
        checkSetup();
    }, []);

    const handleKeyPress = (key: string) => {
        if (pin.length < 4 && !isConfirming) {
            setPin(pin + key);
        } else if (isConfirming && confirmPin.length < 4) {
            setConfirmPin(confirmPin + key);
        }
    };

    const handleBackspace = () => {
        if (isConfirming) {
            setConfirmPin(prev => prev.slice(0, -1));
        } else {
            setPin(prev => prev.slice(0, -1));
        }
    };

    const handleLoginAttempt = async () => {
        if (pin.length === 4) {
            setIsVerifying(true);
            setError('');
            try {
                // The "real" test is to decrypt something. Let's try to decrypt the encrypted pin itself.
                const storedEncryptedPinCheck = await db.getConfig('encryptedPinCheck');
                await CryptoService.decrypt(storedEncryptedPinCheck, pin);
                onLogin(pin);
            } catch(e) {
                setError('Invalid PIN. Please try again.');
                setPin('');
                setIsVerifying(false);
            }
        }
    };

    useEffect(() => {
        if (!isSetup) {
            if (confirmPin.length === 4) {
                if (pin === confirmPin) {
                    const setupPin = async () => {
                        const encryptedPinCheck = await CryptoService.encrypt(pin, pin);
                        await db.saveConfig('encryptedPinCheck', encryptedPinCheck);
                        onPinSet(pin);
                    };
                    setupPin();
                } else {
                    setError("PINs don't match. Please try again.");
                    setPin('');
                    setConfirmPin('');
                    setIsConfirming(false);
                }
            }
        } else {
            if (pin.length === 4) {
                handleLoginAttempt();
            }
        }
    }, [pin, confirmPin]);


    useEffect(() => {
        if (pin.length === 4 && !isSetup && !isConfirming) {
            setIsConfirming(true);
        }
    }, [pin, isSetup, isConfirming]);

    if (isLoading) {
        return <div className="loading"></div>;
    }

    const currentPin = isConfirming ? confirmPin : pin;
    const title = isSetup ? "Enter PIN" : (isConfirming ? "Confirm PIN" : "Create a PIN");

    return (
        <div className="auth-container">
            <div className="auth-card">
                <h2>{title}</h2>
                <div className="auth-error">{error || (isVerifying && 'Verifying...')}</div>
                <div className="pin-display">
                    {isVerifying ? (
                        <div className="pin-spinner-container"><div className="spinner-small"></div></div>
                    ) : (
                        Array(4).fill(0).map((_, i) => (
                            <span key={i} className={i < currentPin.length ? 'filled' : ''}></span>
                        ))
                    )}
                </div>
                <div className="keypad">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                        <button key={num} onClick={() => handleKeyPress(String(num))} disabled={isVerifying}>{num}</button>
                    ))}
                    <button disabled={isVerifying}></button>
                    <button onClick={() => handleKeyPress('0')} disabled={isVerifying}>0</button>
                    <button onClick={handleBackspace} disabled={isVerifying}>&larr;</button>
                </div>
            </div>
        </div>
    );
};

const MainApp: React.FC<{ pin: string }> = ({ pin }) => {
    const [sessions, setSessions] = useState<Session[]>([]);
    const [tasks, setTasks] = useState<Task[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [status, setStatus] = useState({ message: '', type: '' });
    const [selectedSession, setSelectedSession] = useState<Session | null>(null);
    const [view, setView] = useState<'sessions' | 'tasks'>('sessions');
    const [industry, setIndustry] = useState<string>('general');
    
    useEffect(() => {
        const loadData = async () => {
            try {
                const [loadedSessions, loadedTasks, savedIndustry] = await Promise.all([
                    db.getAllSessions(),
                    db.getAllTasks(),
                    db.getConfig('industry')
                ]);
                setSessions(loadedSessions);
                setTasks(loadedTasks);
                if (savedIndustry) {
                    setIndustry(savedIndustry);
                }
            } catch (error) {
                showStatus('Failed to load data.', 'error');
            } finally {
                setIsLoading(false);
            }
        };
        loadData();
    }, []);

    const showStatus = (message: string, type: 'success' | 'error' | 'info', duration = 3000) => {
        setStatus({ message, type });
        setTimeout(() => setStatus({ message: '', type: '' }), duration);
    };

    const handleAddSession = async (session: Omit<Session, 'id' | 'timestamp' | 'notes'>, notes: string, audioBlob: Blob | null) => {
        try {
            const encryptedNotes = await CryptoService.encrypt(notes, pin);
            const timestamp = Date.now();

            const newSession: Session = { ...session, notes: encryptedNotes, timestamp };
            if (audioBlob) {
                newSession.analysisStatus = 'none';
            }
            
            const id = await db.addSession(newSession);
            
            if (audioBlob) {
                await db.saveAudioBlob(id, audioBlob);
            }

            setSessions(prev => [{ ...newSession, id }, ...prev]);
            showStatus('Session saved successfully.', 'success');
            return true;
        } catch (error) {
            showStatus('Failed to save session.', 'error');
            return false;
        }
    };
    
    const handleDeleteSession = async (id: number) => {
        if (window.confirm('Are you sure you want to delete this session? This action cannot be undone.')) {
            try {
                await db.deleteSession(id);
                setSessions(prev => prev.filter(s => s.id !== id));
                // Also delete associated tasks
                const tasksToDelete = tasks.filter(t => t.sessionId === id);
                for (const task of tasksToDelete) {
                    await db.deleteTask(task.id!);
                }
                setTasks(prev => prev.filter(t => t.sessionId !== id));
                showStatus('Session deleted.', 'success');
            } catch {
                showStatus('Failed to delete session.', 'error');
            }
        }
    };

    const handleUpdateSession = async (updatedSession: Session) => {
        try {
            await db.updateSession(updatedSession);
            setSessions(prev => prev.map(s => s.id === updatedSession.id ? updatedSession : s));
            if (selectedSession?.id === updatedSession.id) {
                setSelectedSession(updatedSession);
            }
        } catch (error) {
            console.error("Failed to update session:", error);
            showStatus('Failed to update session.', 'error');
        }
    };

    const handleAddTask = async (task: Omit<Task, 'id' | 'timestamp'>) => {
        try {
            const newTask = { ...task, timestamp: Date.now() };
            const id = await db.addTask(newTask);
            setTasks(prev => [{ ...newTask, id }, ...prev]);
            showStatus('Task added.', 'success');
            return true;
        } catch {
            showStatus('Failed to add task.', 'error');
            return false;
        }
    };

    const handleUpdateTask = async (updatedTask: Task) => {
        try {
            await db.updateTask(updatedTask);
            setTasks(prev => prev.map(t => t.id === updatedTask.id ? updatedTask : t));
        } catch (error) {
            showStatus('Failed to update task.', 'error');
        }
    };

    const handleDeleteTask = async (id: number) => {
        try {
            await db.deleteTask(id);
            setTasks(prev => prev.filter(t => t.id !== id));
            showStatus('Task deleted.', 'success');
        } catch {
            showStatus('Failed to delete task.', 'error');
        }
    };

    const handleIndustryChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newIndustry = e.target.value;
        setIndustry(newIndustry);
        await db.saveConfig('industry', newIndustry);
    };

    return (
        <div className="container">
            <header>
                <h1>AI Notes</h1>
                <p>You On-Device, Private, AI Powered Notes</p>
                <p className="author-credit">by AC MiNDS.</p>
                <div className="settings-container">
                     <span>Prompt context:</span>
                    <select id="industrySelector" value={industry} onChange={handleIndustryChange}>
                        <option value="general">General</option>
                        <option value="therapy">Therapy Session</option>
                        <option value="medical">Medical Dictation</option>
                        <option value="legal">Legal Note</option>
                        <option value="business">Business Meeting</option>
                    </select>
                </div>
            </header>

            {status.message && <div className={`status ${status.type}`}>{status.message}</div>}

            <ViewSwitcher view={view} setView={setView} />

            {isLoading ? (
                <div className="loading"><div className="spinner"></div>Loading...</div>
            ) : (
                view === 'sessions' ? (
                    <>
                        <NewSessionForm onAddSession={handleAddSession} showStatus={showStatus} />
                        <SessionsList sessions={sessions} onSelect={setSelectedSession} onDelete={handleDeleteSession} pin={pin} />
                    </>
                ) : (
                    <TaskManager 
                        tasks={tasks}
                        onAddTask={handleAddTask}
                        onUpdateTask={handleUpdateTask}
                        onDeleteTask={handleDeleteTask}
                        sessions={sessions}
                    />
                )
            )}

            {selectedSession && (
                <SessionDetailModal
                    session={selectedSession}
                    onClose={() => setSelectedSession(null)}
                    onDelete={handleDeleteSession}
                    onUpdate={handleUpdateSession}
                    onAddTask={handleAddTask}
                    pin={pin}
                />
            )}
        </div>
    );
};

const ViewSwitcher: React.FC<{ view: 'sessions' | 'tasks', setView: (view: 'sessions' | 'tasks') => void }> = ({ view, setView }) => (
    <div className="view-switcher">
        <button className={view === 'sessions' ? 'active' : ''} onClick={() => setView('sessions')}>Sessions</button>
        <button className={view === 'tasks' ? 'active' : ''} onClick={() => setView('tasks')}>Tasks</button>
    </div>
);

type ShowStatusType = (message: string, type: 'success' | 'error' | 'info', duration?: number) => void;

const NewSessionForm: React.FC<{ 
    onAddSession: (session: Omit<Session, 'id' | 'timestamp' | 'notes'>, notes: string, audioBlob: Blob | null) => Promise<boolean>,
    showStatus: ShowStatusType 
}> = ({ onAddSession, showStatus }) => {
    const [sessionTitle, setSessionTitle] = useState('');
    const [participants, setParticipants] = useState('');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [notes, setNotes] = useState('');
    const [isRecording, setIsRecording] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [recordingType, setRecordingType] = useState<'mic' | 'system'>('mic');
    const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
    const [duration, setDuration] = useState(0);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const chunksRef = useRef<Blob[]>([]);
    const timerRef = useRef<NodeJS.Timeout | null>(null);

    const handleStartRecording = async () => {
        try {
            let stream: MediaStream;
            if (recordingType === 'mic') {
                stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            } else {
                 stream = await (navigator.mediaDevices as any).getDisplayMedia({
                    video: true,
                    audio: true
                });
                if (!stream.getAudioTracks().length) {
                    showStatus("Your system audio is not being shared. Please check the 'Share system audio' box in the prompt.", 'error', 5000);
                    return;
                }
            }
            
            setIsRecording(true);
            setDuration(0);
            timerRef.current = setInterval(() => setDuration(prev => prev + 1), 1000);

            mediaRecorderRef.current = new MediaRecorder(stream);
            mediaRecorderRef.current.ondataavailable = (e) => {
                if (e.data.size > 0) chunksRef.current.push(e.data);
            };
            mediaRecorderRef.current.onstop = () => {
                const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
                setAudioBlob(blob);
                chunksRef.current = [];
                 stream.getTracks().forEach(track => track.stop());
            };
            mediaRecorderRef.current.start();
        } catch (err) {
            console.error("Error starting recording:", err);
            showStatus("Could not start recording. Please ensure you have given microphone permissions.", 'error');
        }
    };

    const handleStopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
            if(timerRef.current) clearInterval(timerRef.current);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!sessionTitle) {
            showStatus('Session title is required.', 'error');
            return;
        }
        setIsSaving(true);
        const success = await onAddSession({
            sessionTitle,
            participants,
            date,
            duration,
            transcript: [],
        }, notes, audioBlob);
        
        if (success) {
            setSessionTitle('');
            setParticipants('');
            setNotes('');
            setAudioBlob(null);
            setDuration(0);
        }
        setIsSaving(false);
    };
    
    const formatTime = (seconds: number) => {
        const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
        const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        return h !== '00' ? `${h}:${m}:${s}` : `${m}:${s}`;
    };

    return (
        <div className="card new-session">
            <h3>New Session</h3>
            <form onSubmit={handleSubmit}>
                <div className="form-grid">
                    <input
                        type="text"
                        placeholder="Session Title"
                        value={sessionTitle}
                        onChange={e => setSessionTitle(e.target.value)}
                        required
                    />
                    <input
                        type="text"
                        placeholder="Participants (optional)"
                        value={participants}
                        onChange={e => setParticipants(e.target.value)}
                    />
                    <input
                        type="date"
                        value={date}
                        onChange={e => setDate(e.target.value)}
                        className="grid-col-span-2"
                    />
                    <textarea
                        placeholder="Enter notes or a summary here..."
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                        rows={5}
                        className="grid-col-span-2"
                    ></textarea>
                </div>
                 <div className="recording-options">
                    <label>Audio Source</label>
                    <div className="toggle-switch">
                        <button type="button" className={recordingType === 'mic' ? 'active' : ''} onClick={() => setRecordingType('mic')}>Microphone</button>
                        <button type="button" className={recordingType === 'system' ? 'active' : ''} onClick={() => setRecordingType('system')}>System Audio</button>
                    </div>
                </div>
                <div className="recording-controls">
                    {!isRecording ? (
                        <button type="button" className="btn-record" onClick={handleStartRecording}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M8 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 1A5 5 0 1 1 8 3a5 5 0 0 1 0 10z"/><path d="M10 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/></svg>
                            Record
                        </button>
                    ) : (
                        <button type="button" className="btn-record recording" onClick={handleStopRecording}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M5.5 5.5A.5.5 0 0 1 6 6v4a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm4 0a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5z"/><path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm15 0a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2z"/></svg>
                            Stop ({formatTime(duration)})
                        </button>
                    )}
                </div>
                {audioBlob && <div className="status info">Audio recorded. Save the session to attach it.</div>}
                <button type="submit" className="btn-primary" disabled={isSaving || isRecording} style={{marginTop: '16px'}}>
                    {isSaving ? 'Saving...' : 'Save Session'}
                </button>
            </form>
        </div>
    );
};

const SessionsList: React.FC<{ sessions: Session[], onSelect: (session: Session) => void, onDelete: (id: number) => void, pin: string }> = ({ sessions, onSelect, onDelete, pin }) => {
    
    if (sessions.length === 0) {
        return <div className="empty-state">No sessions yet. Create one to get started!</div>;
    }

    const decryptAndPreview = (notes: string) => {
        try {
            // This is a simplified preview. In a real app, you might want to cache decrypted previews.
            // For now, let's just show encrypted length as a placeholder for performance.
            return `Encrypted notes...`;
        } catch {
            return "Could not decrypt preview.";
        }
    };

    return (
        <div className="sessions-list">
            <h3>Recent Sessions</h3>
            {sessions.map(session => (
                <div key={session.id} className="session-item" onClick={() => onSelect(session)}>
                    <div className="session-content">
                        <div className="session-header">
                            <span className="session-title">{session.sessionTitle}</span>
                            <span className="session-date">{new Date(session.date).toLocaleDateString()}</span>
                        </div>
                        {session.participants && <p className="session-participants">With: {session.participants}</p>}
                        <p className="session-preview">{decryptAndPreview(session.notes)}</p>
                        {session.analysisStatus && session.analysisStatus !== 'complete' && session.analysisStatus !== 'none' && (
                            <div className={`session-status-indicator ${session.analysisStatus}`}>
                                {session.analysisStatus === 'pending' && <><div className="spinner-small"></div> Processing AI analysis...</>}
                                {session.analysisStatus === 'failed' && <>&#x26A0; AI analysis failed</>}
                            </div>
                        )}
                    </div>
                    <div className="session-actions">
                        <button
                            className="icon-btn"
                            onClick={(e) => { e.stopPropagation(); onDelete(session.id!); }}
                            aria-label="Delete session"
                        >
                           &#x1F5D1;
                        </button>
                    </div>
                </div>
            ))}
        </div>
    );
};

const SessionDetailModal: React.FC<{ 
    session: Session, 
    onClose: () => void, 
    onDelete: (id: number) => void, 
    onUpdate: (session: Session) => void,
    onAddTask: (task: Omit<Task, 'id' | 'timestamp'>) => Promise<boolean>,
    pin: string
}> = ({ session, onClose, onDelete, onUpdate, onAddTask, pin }) => {
    const [decryptedNotes, setDecryptedNotes] = useState('');
    const [isDecrypting, setIsDecrypting] = useState(true);
    const [audioUrl, setAudioUrl] = useState<string | null>(null);
    const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
    const [isEditingNotes, setIsEditingNotes] = useState(false);
    const [editedNotes, setEditedNotes] = useState('');
    const [speakerMap, setSpeakerMap] = useState<{[key: string]: string}>({});
    const [editingSpeaker, setEditingSpeaker] = useState<{chunkIndex: number, oldName: string} | null>(null);
    const [aiAnalysisStatus, setAiAnalysisStatus] = useState<'idle' | 'in_progress' | 'failed' | 'complete'>('idle');
    const [aiProgress, setAiProgress] = useState({ status: '', progress: 0 });

    useEffect(() => {
        const decryptAndLoad = async () => {
            setIsDecrypting(true);
            try {
                const notes = await CryptoService.decrypt(session.notes, pin);
                setDecryptedNotes(notes);
                setEditedNotes(notes);

                const blob = await db.getAudioBlob(session.id!);
                if (blob) {
                    setAudioBlob(blob);
                    setAudioUrl(URL.createObjectURL(blob));
                }

            } catch (error) {
                setDecryptedNotes("Error: Could not decrypt notes. The PIN may be incorrect or data is corrupted.");
            } finally {
                setIsDecrypting(false);
            }
        };
        decryptAndLoad();

        return () => {
            if (audioUrl) {
                URL.revokeObjectURL(audioUrl);
            }
        };
    }, [session, pin]);

    useEffect(() => {
        // Create initial speaker map
        const uniqueSpeakers = [...new Set(session.transcript.map(c => c.speaker))];
        const initialMap: {[key: string]: string} = {};
        uniqueSpeakers.forEach(speaker => {
            initialMap[speaker] = speaker;
        });
        setSpeakerMap(initialMap);
    }, [session.transcript]);

    const handleSaveNotes = async () => {
        try {
            const encryptedNotes = await CryptoService.encrypt(editedNotes, pin);
            onUpdate({ ...session, notes: encryptedNotes, audioBlob });
            setDecryptedNotes(editedNotes);
            setIsEditingNotes(false);
        } catch {
            alert('Failed to save notes.');
        }
    };
    
    const handlePromoteTodoToTask = async (todo: TodoItem, todoIndex: number) => {
        const success = await onAddTask({
            title: todo.text,
            dueDate: null,
            priority: 'medium',
            status: 'todo',
            sessionId: session.id,
            sessionName: session.sessionTitle
        });

        if (success) {
            const updatedTodos = [...(session.todoItems || [])];
            const newTaskId = Date.now(); // Placeholder, real ID comes from DB
            updatedTodos[todoIndex] = { ...todo, promotedToTaskId: newTaskId };
            onUpdate({ ...session, todoItems: updatedTodos, audioBlob });
        }
    };
    
    const handleTodoToggle = (index: number) => {
        const updatedTodos = [...(session.todoItems || [])];
        updatedTodos[index].completed = !updatedTodos[index].completed;
        onUpdate({ ...session, todoItems: updatedTodos, audioBlob });
    };

    const handleRunOnDeviceAnalysis = async () => {
        setAiAnalysisStatus('in_progress');
        onUpdate({ ...session, analysisStatus: 'pending', audioBlob });
        try {
            if (!audioBlob) {
                throw new Error("Audio file not found for this session.");
            }
            
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const arrayBuffer = await audioBlob.arrayBuffer();
            const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);

            const result = await onDeviceAIService.analyze(audioBuffer, (status, progress) => {
                 setAiProgress({ status, progress: progress || 0 });
            });
            
            const todoItems: TodoItem[] = (result.action_items || []).map(text => ({ text, completed: false }));
            onUpdate({ ...session, transcript: result.transcript, summary: result.summary, todoItems, outline: result.outline, analysisStatus: 'complete', audioBlob });
            setAiAnalysisStatus('complete');

        } catch (error) {
            console.error("On-device AI analysis failed:", error);
            setAiAnalysisStatus('failed');
            onUpdate({ ...session, analysisStatus: 'failed', audioBlob });
        }
    };

    const handleSpeakerNameChange = (newName: string) => {
        if (!editingSpeaker) return;
        
        const { oldName } = editingSpeaker;
        const newMap = { ...speakerMap, [oldName]: newName };
        setSpeakerMap(newMap);

        const newTranscript = session.transcript.map(chunk => {
            if (chunk.speaker === oldName) {
                return { ...chunk, speaker: newName };
            }
            return chunk;
        });

        onUpdate({ ...session, transcript: newTranscript, audioBlob });
        setEditingSpeaker(null);
    };

    const getSpeakerClass = (speaker: string) => {
        const speakers = Object.keys(speakerMap);
        const index = speakers.indexOf(speaker);
        return `speaker-style-${(index % 5) + 1}`;
    };

    return (
        <div className="modal active" onClick={onClose}>
            <div className="modal-content" onClick={e => e.stopPropagation()}>
                <button className="close-btn" onClick={onClose}>&times;</button>
                <h2>{session.sessionTitle}</h2>
                <p style={{ color: '#94a3b8', marginBottom: '16px' }}>{new Date(session.date).toLocaleDateString()}{session.participants && ` with ${session.participants}`}</p>
                
                {audioUrl && <AudioPlayer audioUrl={audioUrl} />}

                {session.analysisStatus === 'none' && aiAnalysisStatus !== 'in_progress' && (
                    <div className="action-buttons" style={{ justifyContent: 'center', margin: '20px 0'}}>
                        <button className="btn-ai" onClick={handleRunOnDeviceAnalysis}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M5 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/><path d="M2 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2H2zm12 1a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1h12z"/></svg>
                            Run On-Device Analysis
                        </button>
                    </div>
                )}
                
                {aiAnalysisStatus === 'in_progress' && (
                    <div className="analysis-progress">
                        <div className="spinner-small"></div>
                        <div className="analysis-progress-text">
                            <span>{aiProgress.status}</span>
                            {aiProgress.status.startsWith('Downloading') && (
                                <div className="download-progress-bar">
                                    <div className="download-progress-bar-inner" style={{width: `${aiProgress.progress}%`}}></div>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                
                {aiAnalysisStatus === 'failed' && (
                     <div className="status error">
                        <span>On-device AI analysis failed. Please try again.</span>
                        <button className="btn-secondary" onClick={handleRunOnDeviceAnalysis}>Retry Analysis</button>
                    </div>
                )}

                {session.analysisStatus === 'complete' && (
                    <div className="analysis-section">
                        <div className="analysis-subsection">
                            <h4>&#x1F4DD; Summary</h4>
                            <p>{session.summary}</p>
                        </div>
                         {session.todoItems && session.todoItems.length > 0 && (
                            <div className="analysis-subsection">
                                <h4>&#x2705; Action Items</h4>
                                <ul className="action-items-list">
                                    {session.todoItems.map((todo, index) => (
                                        <li key={index} className={`todo-item ${todo.completed ? 'completed' : ''}`}>
                                            <div className="todo-content" onClick={() => handleTodoToggle(index)}>
                                                <input type="checkbox" readOnly checked={todo.completed} />
                                                <span className="todo-text">{todo.text}</span>
                                            </div>
                                            {todo.promotedToTaskId ? (
                                                <span className="task-promoted-badge">Tasked</span>
                                            ) : (
                                                <button 
                                                    className="btn-promote-task" 
                                                    title="Promote to Task" 
                                                    onClick={() => handlePromoteTodoToTask(todo, index)}>
                                                    &#x2795;
                                                </button>
                                            )}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                        {session.outline && (
                             <div className="analysis-subsection">
                                <h4>&#x1F4D1; Outline</h4>
                                <div className="outline-content">{session.outline}</div>
                            </div>
                        )}
                    </div>
                )}

                <h3>Notes</h3>
                {isDecrypting ? (
                    <div className="loading">Decrypting...</div>
                ) : (
                    isEditingNotes ? (
                        <div>
                            <textarea value={editedNotes} onChange={e => setEditedNotes(e.target.value)} rows={8} style={{ width: '100%' }} />
                            <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                                <button className="btn-primary" onClick={handleSaveNotes}>Save</button>
                                <button className="btn-stop" onClick={() => setIsEditingNotes(false)}>Cancel</button>
                            </div>
                        </div>
                    ) : (
                        <div>
                            <div className="transcript" style={{ whiteSpace: 'pre-wrap' }} onClick={() => setIsEditingNotes(true)}>
                                {decryptedNotes || <span style={{color: '#94a3b8'}}>Click to add notes...</span>}
                            </div>
                        </div>
                    )
                )}
                
                {session.transcript && session.transcript.length > 0 && (
                    <>
                        <h3>Transcript</h3>
                        <div className="transcript">
                            {session.transcript.map((chunk, index) => (
                                <div key={index} className={`transcript-chunk ${getSpeakerClass(chunk.speaker)}`}>
                                   {editingSpeaker?.chunkIndex === index ? (
                                        <input
                                            type="text"
                                            defaultValue={editingSpeaker.oldName}
                                            onBlur={(e) => handleSpeakerNameChange(e.target.value)}
                                            onKeyDown={(e) => e.key === 'Enter' && handleSpeakerNameChange(e.currentTarget.value)}
                                            autoFocus
                                            className="speaker-input"
                                        />
                                   ) : (
                                       <span
                                            className="speaker-label editable"
                                            onClick={() => setEditingSpeaker({ chunkIndex: index, oldName: chunk.speaker })}
                                        >
                                           {speakerMap[chunk.speaker] || chunk.speaker}:
                                        </span>
                                   )}
                                    <p>{chunk.text}</p>
                                </div>
                            ))}
                        </div>
                    </>
                )}

                <div style={{ marginTop: '24px', display: 'flex', justifyContent: 'flex-end' }}>
                    <button className="btn-danger" onClick={() => { onDelete(session.id!); onClose(); }}>Delete Session</button>
                </div>
            </div>
        </div>
    );
};

const AudioPlayer: React.FC<{ audioUrl: string }> = ({ audioUrl }) => {
    const audioRef = useRef<HTMLAudioElement>(null);
    const progressRef = useRef<HTMLDivElement>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);

    useEffect(() => {
        const audio = audioRef.current;
        if (!audio) return;

        const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
        const handleDurationChange = () => setDuration(audio.duration);
        const handleEnded = () => setIsPlaying(false);

        audio.addEventListener('timeupdate', handleTimeUpdate);
        audio.addEventListener('durationchange', handleDurationChange);
        audio.addEventListener('ended', handleEnded);

        return () => {
            audio.removeEventListener('timeupdate', handleTimeUpdate);
            audio.removeEventListener('durationchange', handleDurationChange);
            audio.removeEventListener('ended', handleEnded);
        };
    }, []);
    
    const togglePlayPause = () => {
        if (audioRef.current) {
            if (isPlaying) {
                audioRef.current.pause();
            } else {
                audioRef.current.play();
            }
            setIsPlaying(!isPlaying);
        }
    };

    const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (audioRef.current && progressRef.current) {
            const rect = progressRef.current.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            const width = rect.width;
            const newTime = (clickX / width) * duration;
            audioRef.current.currentTime = newTime;
        }
    };
    
    const formatTime = (time: number) => {
        if (isNaN(time) || time === 0) return '00:00';
        const minutes = Math.floor(time / 60);
        const seconds = Math.floor(time % 60);
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0;

    return (
        <div className="player-controls">
            <audio ref={audioRef} src={audioUrl} preload="metadata"></audio>
            <div className="audio-player">
                <button onClick={togglePlayPause} className="playback-btn">
                    {isPlaying ? '❚❚' : '►'}
                </button>
                <span className="time-display">{formatTime(currentTime)}</span>
                <div className="progress-bar-container" ref={progressRef} onClick={handleProgressClick}>
                    <div className="progress-bar-background"></div>
                    <div className="progress-bar-progress" style={{ width: `${progressPercentage}%` }}></div>
                    <div className="progress-bar-thumb" style={{ left: `${progressPercentage}%` }}></div>
                </div>
                <span className="time-display">{formatTime(duration)}</span>
            </div>
        </div>
    );
};

const TaskManager: React.FC<{
    tasks: Task[],
    onAddTask: (task: Omit<Task, 'id' | 'timestamp'>) => Promise<boolean>,
    onUpdateTask: (task: Task) => void,
    onDeleteTask: (id: number) => void,
    sessions: Session[],
}> = ({ tasks, onAddTask, onUpdateTask, onDeleteTask, sessions }) => {
    const [newTaskTitle, setNewTaskTitle] = useState('');
    const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');
    const [newTaskDueDate, setNewTaskDueDate] = useState<string | null>(null);

    const handleAddTask = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newTaskTitle.trim()) return;
        
        const success = await onAddTask({
            title: newTaskTitle.trim(),
            priority: newTaskPriority,
            dueDate: newTaskDueDate,
            status: 'todo',
        });

        if (success) {
            setNewTaskTitle('');
            setNewTaskPriority('medium');
            setNewTaskDueDate(null);
        }
    };

    return (
        <div className="card">
            <h3>Task Manager</h3>
            <form className="task-form" onSubmit={handleAddTask}>
                <input
                    type="text"
                    placeholder="New task..."
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                />
                <select value={newTaskPriority} onChange={(e) => setNewTaskPriority(e.target.value as any)}>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                </select>
                <input
                    type="date"
                    value={newTaskDueDate || ''}
                    onChange={(e) => setNewTaskDueDate(e.target.value)}
                />
                <button type="submit" className="btn-primary">Add</button>
            </form>

            <div className="task-list">
                {tasks.length > 0 ? tasks.map(task => (
                    <TaskItem 
                        key={task.id} 
                        task={task} 
                        onUpdateTask={onUpdateTask} 
                        onDeleteTask={onDeleteTask} 
                    />
                )) : (
                    <div className="empty-state">No tasks yet.</div>
                )}
            </div>
        </div>
    );
};

const TaskItem: React.FC<{
    task: Task,
    onUpdateTask: (task: Task) => void,
    onDeleteTask: (id: number) => void,
}> = ({ task, onUpdateTask, onDeleteTask }) => {

    const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        onUpdateTask({ ...task, status: e.target.value as any });
    };

    return (
        <div className={`task-item status-${task.status}`}>
            <div className="task-main-content">
                <div className="task-details">
                    <span className="task-title">{task.title}</span>
                    <div className="task-meta">
                        <span className={`priority-badge priority-${task.priority}`}>{task.priority}</span>
                        {task.dueDate && <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>}
                        {task.sessionName && <span className="task-session-link">From: {task.sessionName}</span>}
                    </div>
                </div>
            </div>
            <select className="task-status-selector" value={task.status} onChange={handleStatusChange}>
                <option value="todo">To Do</option>
                <option value="inprogress">In Progress</option>
                <option value="done">Done</option>
            </select>
            <div className="task-actions">
                <button className="icon-btn-delete" onClick={() => onDeleteTask(task.id!)} aria-label="Delete task">&#x1F5D1;</button>
            </div>
        </div>
    );
};

// --- RENDER APP ---
const container = document.getElementById('root');
if (container) {
    const root = createRoot(container);
    root.render(<App />);
}